
import sys,os,datetime;
sys.path.append("Modules/");

import argparse;
import openpyxl;
from openpyxl import Workbook
from ConfigParser import SafeConfigParser
parser=SafeConfigParser()
parser.read("bookConfig.ini")	

global total_Cost;
total_Cost=0;

def Calculate_Cost(booktype):
	##Getting Details per Books
	
	##Date of Issue
	#issueDate="2019-01-02"
	issueDays=raw_input("Enter Book Issue Date:[yyyy-mm-dd]:");
	issueDays=(datetime.date.today())-datetime.datetime.strptime(issueDate, '%Y-%m-%d').date()
	
	##Getting properties values from Config files
	perDay=parser.get(booktype,"perDay")
	minimum=parser.get(booktype,"minimum")
	extraDay=parser.get(booktype,"extraDay")
	extraDayPay=parser.get(booktype,"extraDayPay")
	if extraDayPay=="0":
		extraDayPay=perDay;
		
	totalDays=str(issueDays).split(" ")[0];
	
	##Calculating Cost
	if totalDays<extraDay:
		Cost=minimum;
	else:
		firstDaypays=(float(perDay)*float(extraDay))
		extrapay=(float(extraDayPay)*(float(totalDays)-float(extraDay)))
		Cost=firstDaypays+extrapay
		
	print "-"*25
	print "-"*25
	print "Issue Date:\t"+issueDate
	print "Return Date:\t",datetime.date.today()
	print "Days to Charge:\t",totalDays
	print "Cost for Book:\t",Cost
	print "-"*25
		
	return Cost	
	#total_Cost=total_Cost+Cost;
	
	print "#"*25
	

def generateReceipt():
	Cost=0;total_Cost=0;
	rCost=0;fCost=0;nCost=0;
	##Getting Details 
	name=raw_input("Enter name:");
	print "-"*15 +"RECEIPT FOR BOOKS"+"-"*15
	print "-"*25
	print "Member name :\t",name
	
	##No of books in Regular
	noRBooks=raw_input("no of Regular Books:");	
	print "-"*25
	print "REGULAR BOOKS::"	
	print "-"*25
	for i in range(int(noRBooks)):
		print "Book No #:",i+1
		BookDetails=parser.options('Regular');
		booktype="Regular"
		rCost=Calculate_Cost(booktype);
		total_Cost=total_Cost+float(rCost);
	print 	
	##No of books in Fiction
	noFBooks=raw_input("no of Fiction Books:");	
	print "-"*25
	print "FICTION BOOKS::"
	print "-"*25
	for i in range(int(noFBooks)):
		print "Book No #:",i+1
		BookDetails=parser.options('Fiction');
		booktype="Fiction"
		fCost=Calculate_Cost(booktype);
		total_Cost=total_Cost+float(fCost);
	print 
	##No of books in Novel
	noNBooks=raw_input("no of Novel Books:");
	print "-"*25
	print "NOVEL BOOKS::"
	print "-"*25	
	for i in range(int(noNBooks)):
		print "Book No #:",i+1
		BookDetails=parser.options('Novel');
		booktype="Novel"
		nCost=Calculate_Cost(booktype);
		total_Cost=total_Cost+float(nCost);	
	
	#Total Cost 
	print "#"*25	
	print "Total Cost:\t",total_Cost
	print "#"*25
	
generateReceipt();
	